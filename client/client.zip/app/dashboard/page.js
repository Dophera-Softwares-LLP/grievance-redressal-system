'use client';
import { useEffect, useState } from 'react';
import { TicketsAPI } from '../../services/tickets';
import { Card, CardContent, Typography, Chip, Stack, Button } from '@mui/material';
import Link from 'next/link';

export default function Dashboard() {
  const [tickets, setTickets] = useState([]);

  useEffect(() => { TicketsAPI.mine().then(setTickets).catch(console.error); }, []);

  return (
    <>
      <Stack direction="row" justifyContent="space-between" sx={{ mb: 2 }}>
        <Typography variant="h5">My Tickets</Typography>
        <Button component={Link} href="/tickets/new" variant="contained">New Ticket</Button>
      </Stack>

      <Stack spacing={2}>
        {tickets.map(t => (
          <Card key={t.id}>
            <CardContent>
              <Typography variant="h6">{t.title}</Typography>
              <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                <Chip label={t.status} />
                {t.due_at && <Chip label={`Due: ${new Date(t.due_at).toLocaleString()}`} />}
              </Stack>
            </CardContent>
          </Card>
        ))}
      </Stack>
    </>
  );
}